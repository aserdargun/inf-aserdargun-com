/* INF public-view cache: intentionally no owner/auth fallback or caching. */
const VERSION = "INF-PUBLIC-3d6233c65d080b3963f4c7b706d4f84cbed11b83c7e6c4b5ab69f9bee4176818";
const STATIC_CACHE = `${VERSION}-static`;
const DATA_CACHE = `${VERSION}-data`;
const IMAGE_CACHE = `${VERSION}-images`;
const CURRENT_CACHES = new Set([STATIC_CACHE, DATA_CACHE, IMAGE_CACHE]);
const MAX_ENTRIES = 40;
const STATIC_ASSETS = ["/view/", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/maskable-512.png"];
let cacheWrites = Promise.resolve();

function isSafeResponse(response) {
  return response.ok && !response.redirected && (response.type === "basic" || response.type === "default");
}

function writeBounded(cacheName, request, response) {
  if (!isSafeResponse(response)) return Promise.resolve();
  const work = async () => {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    const requestUrl = typeof request === "string" ? new URL(request, self.location.origin).href : request.url;
    const replacement = keys.some((key) => key.url === requestUrl);
    const candidates = keys.filter((key) => key.url !== requestUrl);
    const overflow = Math.max(0, keys.length + (replacement ? 0 : 1) - MAX_ENTRIES);
    const deletions = await Promise.all(candidates.slice(0, overflow).map((key) => cache.delete(key)));
    if (deletions.some((deleted) => !deleted)) throw new Error("Cache eviction failed");
    await cache.put(request, response.clone());
  };
  const next = cacheWrites.then(work, work);
  cacheWrites = next.catch(() => undefined);
  return next;
}

async function writeBestEffort(cacheName, request, response) {
  try { await writeBounded(cacheName, request, response); } catch { /* A fresh network response remains authoritative. */ }
}

async function matchBestEffort(cacheName, ...requests) {
  try {
    const cache = await caches.open(cacheName);
    for (const request of requests) {
      const cached = await cache.match(request);
      if (cached) return cached;
    }
  } catch { /* Cache storage is optional for online responses. */ }
  return undefined;
}

function publicCatalog(pathname) {
  return pathname === "/api/public/infographics" || /^\/api\/public\/infographics\/[0-9a-f-]+$/i.test(pathname);
}

function publicImage(pathname) {
  return pathname.startsWith("/api/public/images/");
}

function viewNavigation(request, pathname) {
  return pathname === "/view" || pathname === "/view/" || (request.mode === "navigate" && pathname.startsWith("/view/"));
}

function staticAsset(pathname) {
  return pathname === "/manifest.webmanifest" || pathname.startsWith("/icons/") || pathname.startsWith("/_next/static/");
}

function oldInfPublicCache(name) {
  return (name.startsWith("INF-PUBLIC-") || name.startsWith("PUBLIC-CACHE-")) && !CURRENT_CACHES.has(name);
}

self.addEventListener("install", (event) => event.waitUntil((async () => {
  const cache = await caches.open(STATIC_CACHE);
  await Promise.all(STATIC_ASSETS.map(async (asset) => {
    const response = await fetch(asset);
    if (isSafeResponse(response)) await cache.put(asset, response);
  }));
  await self.skipWaiting();
})()));

self.addEventListener("activate", (event) => event.waitUntil((async () => {
  await Promise.all((await caches.keys()).filter(oldInfPublicCache).map((name) => caches.delete(name)));
  await self.clients.claim();
})()));

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (viewNavigation(request, url.pathname)) {
    event.respondWith((async () => {
      let response;
      try {
        response = await fetch(request);
      } catch (networkError) {
        const cached = await matchBestEffort(STATIC_CACHE, request, "/view/");
        if (cached) return cached;
        throw networkError;
      }
      await writeBestEffort(STATIC_CACHE, request, response);
      return response;
    })());
    return;
  }
  if (publicCatalog(url.pathname)) {
    event.respondWith((async () => {
      let response;
      try {
        response = await fetch(request);
      } catch (networkError) {
        const cached = await matchBestEffort(DATA_CACHE, request);
        if (cached) return cached;
        throw networkError;
      }
      await writeBestEffort(DATA_CACHE, request, response);
      return response;
    })());
    return;
  }
  if (publicImage(url.pathname)) {
    let revalidation;
    const responsePromise = (async () => {
      const cached = await matchBestEffort(IMAGE_CACHE, request);
      revalidation = fetch(request).then(async (response) => {
        await writeBestEffort(IMAGE_CACHE, request, response);
        return response;
      }).catch(() => undefined);
      if (cached) return cached;
      const response = await revalidation;
      if (response) return response;
      throw new Error("Offline");
    })();
    event.respondWith(responsePromise);
    event.waitUntil(responsePromise.then(() => revalidation).catch(() => undefined));
    return;
  }
  if (staticAsset(url.pathname)) {
    event.respondWith((async () => {
      const cached = await matchBestEffort(STATIC_CACHE, request);
      if (cached) return cached;
      const response = await fetch(request);
      await writeBestEffort(STATIC_CACHE, request, response);
      return response;
    })());
  }
});
